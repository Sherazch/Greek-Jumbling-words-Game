package Greek_krypto;

public interface WordsHandlerInterface {
	void getRandomWords();
	void makeCharArray();
	void SetScoreColors();
	void SetScores();
	int getValueofChar(char a);
	String ArrangeValueofChar();
	int makePosition();
	int[] getPos(int x);
}
