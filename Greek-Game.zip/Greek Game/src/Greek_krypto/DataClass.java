package Greek_krypto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DataClass {
	static String sperator = ",";

	public DataClass() {
		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader("words.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("Error");
		}
		String line = "";
		try {
			while ((line = in.readLine()) != null) {
				totalWords += line;
			}
			in.close();
		} catch (IOException e) {
		}

	}

	// 5 letters...
	static String totalWords = "prawn,tiger,above,abuse,trick," + "actor,table,skill,adopt,adult,zebra,again,carry,"
			+ "agent,champ,ahead,write,album,alert,swing,catch," + "sweet,story,usage,score,grass,sleep,crops,cause,"
			+ "alive,allow,alone,happy,brown,build,built,buyer," + "cable,calif,close,going,woman,queen,madam,vixen,"
			// 8 letters...
			+ "absolute,abstract,feminine,opposite,princess,prepared,"
			+ "academic,accepted,accident,accuracy,accurate,achieved,"
			+ "acquired,activity,birthday,boundary,breaking,breeding,"
			+ "building,saturday,business,calendar,campaign,capacity,"
			+ "casualty,catching,category,customer,database,daughter,"
			+ "daylight,deadline,deciding,decision,decrease,deferred,"
			+ "definite,delicate,delivery,hundered,families,question,"
			// 10 letters...
			+ "aboveboard,washington,basketball,weathering,characters,"
			+ "literature,leadership,california,mattresses,dictionary,"
			+ "perfection,volleyball,depression,homecoming,technology,"
			+ "maleficent,watermelon,appreciate,relaxation,convection,"
			+ "government,abominable,salmonella,strawberry,aberration,"
			+ "retirement,television,contraband,alzheimers,activities,"
			+ "friendship,loneliness,punishment,university,cinderella,"
			+ "confidence,restaurant,helicopter,understand,everything";

	static char[][] scoreArray = { { 'a', 1 }, { 'b', 2 }, { 'c', 3 }, { 'd', 2 }, { 'e', 1 }, { 'f', 5 }, { 'g', 6 },
			{ 'h', 4 }, { 'i', 2 }, { 'j', 5 }, { 'k', 1 }, { 'l', 2 }, { 'm', 7 }, { 'n', 3 }, { 'o', 6 }, { 'p', 5 },
			{ 'q', 6 }, { 'r', 3 }, { 's', 2 }, { 't', 2 }, { 'u', 4 }, { 'v', 6 }, { 'w', 7 }, { 'x', 8 }, { 'y', 9 },
			{ 'z', 9 } };
}
