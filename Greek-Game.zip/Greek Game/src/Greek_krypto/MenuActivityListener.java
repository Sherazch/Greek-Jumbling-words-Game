package Greek_krypto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public interface MenuActivityListener extends ActionListener{
	public void actionPerformed(ActionEvent e);
}
