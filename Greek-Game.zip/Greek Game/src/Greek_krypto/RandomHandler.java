package Greek_krypto;

import java.util.Random;

public class RandomHandler {
	// Repetition allowed after RepeatAfter.
	public static int RepeatAfter;
	private static int noRepeat[];
	// value of current position save the upcoming random distinct value
	private static int NewVal;

	public static void reset() {
		noRepeat = new int[RepeatAfter];
		NewVal = 0;
		for (int j = 0; j < noRepeat.length; j++) {
			noRepeat[j] = RepeatAfter;
		}
	}

	public static int checkRepeating(int value) {// recursive func..
		int i = 0;
		while (i < noRepeat.length) {
			if (noRepeat[i] == value) {

				break;
			}
			i++;
		}
		if (i == noRepeat.length) {
			noRepeat[NewVal] = value;
			// System.out.println(NewVal+"__"+value+" >>"+noRepeat.length);
			NewVal++;

			if (NewVal == noRepeat.length) {
				reset();
			}

			return value;
		}
		/*
		 * recursion and next random number generation
		 */
		Random rand = new Random();
		value = rand.nextInt(RepeatAfter);
		return checkRepeating(value);

	}

	public static int nextPosition(int value) {// recursive func..
		int i = 0;
		while (i < noRepeat.length) {
			if (noRepeat[i] == value) {

				break;
			}
			i++;
		}
		if (i == noRepeat.length) {
			noRepeat[NewVal] = value;
			// System.out.println(NewVal+"__"+value+" >>"+noRepeat.length);
			NewVal++;

			if (NewVal == noRepeat.length) {
				reset();
			}

			return value;
		}
		/*
		 * recursion and next random number generation
		 */
		
		int x = value;
		Random rand = new Random();
		do {
			
			value = rand.nextInt(8);
			value = getPos(value, x);
			System.out.print(".");
		} while (value == -1);
		
		return nextPosition(value);

	}

	public static int getPos(int value, int x) {
		int limit = Pane.order * Pane.order;
		if (value == 0 && x - (Pane.order + 1) > 0 && x % Pane.order != 0) {
			return x - (Pane.order + 1);
		}
		if (value == 1 && x - (Pane.order) > 0) {
			return x - (Pane.order);
		}
		if (value == 2 && x - (Pane.order - 1) > 0 && (x - (Pane.order - 1)) % Pane.order != 0) {
			return x - (Pane.order - 1);
		}
		if (value == 3 && x - 1 > 0 && x % Pane.order != 0) {
			return x - 1;
		}
		if (value == 4 && x + 1 < limit && (x + 1) % Pane.order != 0) {
			return x + 1;
		}
		if (value == 5 && x + (Pane.order - 1) < limit && (x + Pane.order) % Pane.order != 0) {
			return x + (Pane.order - 1);
		}
		if (value == 6 && x + (Pane.order) < limit) {
			return x + (Pane.order);
		}
		if (value == 7 && x + (Pane.order + 1) < limit && (x + Pane.order + 1) % Pane.order != 0) {
			return x + (Pane.order + 1);
		}
		return -1;
	}

}
